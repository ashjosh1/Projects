package com.WalletJDBC.Dao1;

public interface Querymapper {
	public static final String INSERT_QUERY="INSERT INTO BankAccount VALUES(AccountDetails_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	public static final String AccountDetails_QUERY_SEQUENCE="SELECT AccountDetails_sequence.CURRVAL FROM DUAL";
	public static final String INSERT_QUERY1 = "select * from BankAccount where accountnumber=? AND pin=?";
	public static final String UPDATE_Deposit = "update BankAccount set balance=balance+? where accountnumber=? AND pin=?";
	public static final String INSERT_QUERY2 = "select * from BankAccount where accountnumber=? AND pin=?";
	public static final String UPDATE_WithDraw = "update BankAccount set balance=balance-? where accountnumber=? AND pin=?";
	public static final String INSERT_QUERY3 = "select * from BankAccount where accountnumber=? AND pin=? ";
	public static final String UPDATE_Deposit1 = "update BankAccount set balance=balance+? where accountnumber=? ";
	public static final String INSERT_QUERY24= "select  * from BankAccount where accountnumber=? ";
	public static final String INSERT_QUERY25= "select  * from BankAccount where accountnumber=? AND pin=? ";
	public static final String UPDATE_WithDraw1 = "update BankAccount set balance=balance-? where accountnumber=? ";
	public static final String CHECK_Query="select accountnumber from BankAccount where accountnumber=?";
	public static final String TRANSINSERT_QUERY1 = "insert into  transaction values(trans_id_sequence.NEXTVAL,?,?,?,?) ";
	
	public static final String trans_id_SEQUENCE="SELECT trans_id_sequence.CURRVAL FROM DUAL";
	public static final String SELECT_Query = "select * from transaction where accnum=? ";
	//public static final String SELECT_Query1 = "select * from transaction where accnum=? ";
	

}

/*create table BankAccount(
accountnumber number(20),
name varchar2(20),mobile varchar2(20),email varchar2(20),accounttype varchar2(20),pin varchar2(20),gender varchar2(30),
age varchar2(20),balance number(20),address varchar2(20));

create sequence AccountDetails_sequence;

create table transaction(
transid number(10), amount number(20),transtype varchar2(20), accnum number(20), date1 Date);

create sequence  trans_id_sequence;

select * from BankAccount;
select * from transaction;*/

