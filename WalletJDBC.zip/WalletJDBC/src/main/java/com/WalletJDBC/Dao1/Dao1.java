package com.WalletJDBC.Dao1;

import com.WalletJDBC.Exception.WalletException;
import com.WalletJDBC.bean.Customer;

public interface Dao1 {
	

	
		long CreateAccount(Customer c) throws WalletException;

		boolean ShowBalance(long accnum, String pin1) throws WalletException;

		boolean Deposit(long accnum, String pin1, String amount) throws WalletException;

		boolean getWithDrawal(long accnum, String pin1, String amount)throws WalletException;

		

		boolean PrintTransaction(long accnum, String pin1) throws WalletException;

		boolean getFundTransaction(long accnum, long accnum1, String pin1, String amount) throws WalletException;

	}



