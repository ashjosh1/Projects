package com.WalletJDBC.Dao1;


	import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.WalletJDBC.Exception.WalletException;
import com.WalletJDBC.bean.Customer;
import com.WalletJDBC.bean.Transaction;
import com.wallet.Connection.DB.DBConnection;




	public class DAOimpl1 implements Dao1{
		
		Logger logger=Logger.getRootLogger();
		Customer customer=new Customer();
		int transid=0;
	public void DAOImpl() {
			
			PropertyConfigurator.configure("resources//log4j.properties");
		}@SuppressWarnings("resource")

		@Override
		public long CreateAccount(Customer c) throws WalletException {
			// TODO Auto-generated method stub
			
			Connection connection = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			long AccountNumber=0L;
			int queryResult=0;
			try
			{	
				preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY);

				preparedStatement.setString(1,c.getName());
				preparedStatement.setString(2,c.getMobile());
				preparedStatement.setString(3,c.getEmail());
				preparedStatement.setString(4,c.getAccounttype());
				preparedStatement.setString(5,c.getPin());
				preparedStatement.setString(6,c.getGender());
				preparedStatement.setString(7,c.getAge());
				preparedStatement.setDouble(8,c.getBalance());
				preparedStatement.setString(9,c.getAddress());
					queryResult=preparedStatement.executeUpdate();
			
		preparedStatement = connection.prepareStatement(Querymapper.AccountDetails_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					AccountNumber=resultSet.getInt(1);
							
				}
					
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting  details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return AccountNumber;
			}
		 }
				
			catch(Exception ex) {
				throw new WalletException(ex.getMessage());
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new WalletException("Error in closing db connection");	
				}
			}
			
				}

		@Override
		public  boolean ShowBalance(long accnum, String pin1) throws WalletException {
			// TODO Auto-generated method stub
			Customer c=new Customer();
			Connection connection = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			//double balance=0.00;
			//int queryResult=0;
			
		
	try {
		preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY1);
		preparedStatement.setLong(1,accnum);
		preparedStatement.setString(2,pin1);
		
		//preparedStatement = connection.prepareStatement(QueryMapper.AccountDetails_QUERY_SEQUENCE);
		resultSet=preparedStatement.executeQuery();
		
		if(resultSet.next()) {
			
				double balance=resultSet.getDouble("balance");
							c.setBalance(balance);
							c.setAccountnumber(resultSet.getLong("accountnumber"));
							c.setName(resultSet.getString("name"));
				System.out.println(c);
				
				}
				
				
		else
			throw new WalletException("invalid");
		}
			
		
		
			
		catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	return true;


		
			}

		@Override
		public boolean Deposit(long accnum, String pin1, String amount) throws WalletException {
			// TODO Auto-generated method stub
			Customer c=new Customer();
			Transaction t=new Transaction();
			Connection connection = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			ResultSet resultSet1 = null;
			int QueryResult=0;
			
			try {
				preparedStatement=connection.prepareStatement(Querymapper.UPDATE_Deposit);
				preparedStatement.setDouble(1,Double.parseDouble(amount));
				preparedStatement.setLong(2,accnum);
				preparedStatement.setString(3,pin1);
				resultSet=preparedStatement.executeQuery();
				preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY2 );
				preparedStatement.setLong(1,accnum);
				preparedStatement.setString(2,pin1);
				resultSet=preparedStatement.executeQuery();
				
				
				if(resultSet.next()) {
					double balance=resultSet.getDouble("balance");
					c.setBalance(balance);
					c.setAccountnumber(resultSet.getLong("accountnumber"));
				//	System.out.println("hii");
		c.setName(resultSet.getString("name"));
		System.out.println(c);
		preparedStatement=connection.prepareStatement(Querymapper.TRANSINSERT_QUERY1);
		preparedStatement.setDouble(1,Double.parseDouble(amount));
		preparedStatement.setLong(3,accnum);
		preparedStatement.setString(2,"Deposit");
		
		//resultSet=preparedStatement.executeQuery();
		PreparedStatement date=connection.prepareStatement("select sysdate from dual");
		
		ResultSet r=date.executeQuery();
		if(r.next()) {
			Date date1=r.getDate(1);
			System.out.println(date1);
			preparedStatement.setDate(4, date1);
		   QueryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(Querymapper.trans_id_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
							
				}
			
			
		
				
				
			return true;
				}else {
			
			
				throw new WalletException("invalid");
			}
				
				}}
			
			
				
			catch(Exception ex) {
				throw new WalletException(ex.getMessage());
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					sqlException.printStackTrace();
					throw new WalletException("Error in closing db connection");	
				}
			}
			return true;

			
			
		
		

}

		@Override
		public boolean getWithDrawal(long accnum, String pin1, String amount) throws WalletException {
			// TODO Auto-generated method stub
			Customer c=new Customer();
			Transaction t=new Transaction();
			Connection connection = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			ResultSet resultSet1 = null;
			int QueryResult=0;
			
			try {
				preparedStatement=connection.prepareStatement(Querymapper.UPDATE_WithDraw);
				preparedStatement.setDouble(1,Double.parseDouble(amount));
				preparedStatement.setLong(2,accnum);
				preparedStatement.setString(3,pin1);
				resultSet=preparedStatement.executeQuery();
				preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY3 );
				preparedStatement.setLong(1,accnum);
				preparedStatement.setString(2,pin1);
				resultSet=preparedStatement.executeQuery();
				
				
				if(resultSet.next()) {
					double balance=resultSet.getDouble("balance");
					c.setBalance(balance);
					c.setAccountnumber(resultSet.getLong("accountnumber"));
				//	System.out.println("hii");
		c.setName(resultSet.getString("name"));
		System.out.println(c);
		preparedStatement=connection.prepareStatement(Querymapper.TRANSINSERT_QUERY1);
		preparedStatement.setDouble(1,Double.parseDouble(amount));
		preparedStatement.setLong(3,accnum);
		preparedStatement.setString(2,"Deposit");
		
		//resultSet=preparedStatement.executeQuery();
		PreparedStatement date=connection.prepareStatement("select sysdate from dual");
		
		ResultSet r=date.executeQuery();
		if(r.next()) {
			Date date1=r.getDate(1);
			System.out.println(date1);
			preparedStatement.setDate(4, date1);
		   QueryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(Querymapper.trans_id_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
							
				}
				
				return true;
					}else {
				
				
					throw new WalletException("invalid");
				}
					
					}}
				
				
					
				catch(Exception ex) {
					throw new WalletException(ex.getMessage());
				}
				finally
				{
					try 
					{
						preparedStatement.close();
						connection.close();
					}
					catch (SQLException sqlException) 
					{
						logger.error(sqlException.getMessage());
						sqlException.printStackTrace();
						throw new WalletException("Error in closing db connection");	
					}
				}
				return true;

				
				
			
			

	}

		@Override
		public boolean PrintTransaction(long accnum, String pin1) throws WalletException {
			// TODO Auto-generated method stub

			Transaction td=new Transaction();
			Connection connection = DBConnection.getInstance().getConnection();	

			PreparedStatement preparedStatement=null;
			PreparedStatement preparedStatement1=null;
			ResultSet resultSet = null;
			ResultSet resultSet1 = null;
			ResultSet transresult=null;
			try {
						
				preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY25);
				preparedStatement.setLong(1, accnum);
				preparedStatement.setString(2, pin1);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					//System.out.println("hello");
					preparedStatement1=connection.prepareStatement(Querymapper.SELECT_Query);
					preparedStatement1.setLong(1, accnum);
					resultSet1=preparedStatement1.executeQuery();
					while(resultSet1.next())
					{//System.out.println("hello");
						td.setTranstype(resultSet1.getString("transtype"));
						td.setAmount(resultSet1.getDouble("amount"));
						td.setDate(resultSet1.getDate("date1"));
						System.out.println(td);
					}
				}
				else
					
					/*transStatement=connection.prepareStatement(Querymapper.INSERT_QUERY24);
		 			transStatement.setLong(1, accnum);
		 			transresult=transStatement.executeQuery();
	                          if(!pin1.equalsIgnoreCase(transresult.getString("pin"))) {
							     System.err.println("Enter the correct pin.Invalid User");
							       }	
						         else {
						        	 transStatement=connection.prepareStatement(Querymapper.SELECT_Query);
						 			transStatement.setLong(1, accnum);
						 			transresult=transStatement.executeQuery();
						        	 preparedStatement=connection.prepareStatement(Querymapper.SELECT_Query);
										preparedStatement.setLong(1, accnum);
										resultSet1=preparedStatement.executeQuery();
						 			while(resultSet1.next()) {
						 				td.setTranstype(resultSet1.getString("transtype"));
						 				td.setAmount(resultSet1.getDouble("balance"));
						 				td.setDate(resultSet1.getDate("transdate"));
						 				System.out.println(td);
						 			}
			                        }
	                   }
			else {*/
				System.err.println("customer with the account number "+accnum+" Not existed");
			}
			catch(SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new WalletException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					throw new WalletException("Error in closing db connection");	
				}
			}
				
				return false;
				
				



			
		}

		@Override
		public boolean getFundTransaction(long accnum, long accnum1, String pin1, String amount)
				throws WalletException {
			// TODO Auto-generated method stub
			Customer c=new Customer();
			Transaction t=new Transaction();
			Connection connection = DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			ResultSet resultSet1 = null;
			int QueryResult=0;
			
			try {
				preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY24 );
				preparedStatement.setLong(1,accnum);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next()) {
				double balance=resultSet.getDouble("balance");
				if(balance<Double.parseDouble(amount)) {
					throw new WalletException("invalid");
				}else {
				preparedStatement=connection.prepareStatement(Querymapper.UPDATE_Deposit1);
				preparedStatement.setDouble(1,Double.parseDouble(amount));
				preparedStatement.setLong(2,accnum1);
				resultSet=preparedStatement.executeQuery();
				
				preparedStatement=connection.prepareStatement(Querymapper.UPDATE_WithDraw1);
				preparedStatement.setDouble(1,Double.parseDouble(amount));
				preparedStatement.setLong(2,accnum);
				resultSet=preparedStatement.executeQuery();
				preparedStatement=connection.prepareStatement(Querymapper.INSERT_QUERY25 );
				preparedStatement.setLong(1,accnum);
				preparedStatement.setString(2,pin1);
				resultSet=preparedStatement.executeQuery();

				if(resultSet.next()) {
					double balance1=resultSet.getDouble("balance");
					c.setBalance(balance1);
					c.setAccountnumber(resultSet.getLong("accountnumber"));
				//	System.out.println("hii");
		c.setName(resultSet.getString("name"));
		System.out.println(c);
		preparedStatement=connection.prepareStatement(Querymapper.TRANSINSERT_QUERY1);
		preparedStatement.setDouble(1,Double.parseDouble(amount));
		preparedStatement.setLong(3,accnum);
		preparedStatement.setString(2,"Deposit");
		
		//resultSet=preparedStatement.executeQuery();
		PreparedStatement date=connection.prepareStatement("select sysdate from dual");
		
		ResultSet r=date.executeQuery();
		if(r.next()) {
			Date date1=r.getDate(1);
			System.out.println(date1);
			preparedStatement.setDate(4, date1);
		   QueryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(Querymapper.trans_id_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
							
				}
				
				return true;
					}else {
				
				
					throw new WalletException("invalid");
				}
					
					
				}}}}
				
					
				catch(Exception ex) {
					throw new WalletException(ex.getMessage());
				}
				finally
				{
					try 
					{
						preparedStatement.close();
						connection.close();
					}
					catch (SQLException sqlException) 
					{
						logger.error(sqlException.getMessage());
						sqlException.printStackTrace();
						throw new WalletException("Error in closing db connection");	
					}
				}
				return true;

				
				}
				
	}		
			