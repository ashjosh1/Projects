package com.WalletJDBC.service;

import com.WalletJDBC.Exception.WalletException;
import com.WalletJDBC.bean.Customer;

public interface Service {

	boolean validateCustomer(Customer c) throws WalletException;

	long CreateAccount(Customer c) throws WalletException;

	boolean ShowBalance(long accnum, String pin1) throws WalletException;

	boolean getdeposit(long accnum, String pin1, String amount) throws WalletException;

	boolean getWithDraw(long accnum, String pin1, String amount)throws WalletException;

	

	boolean PrintTransaction(long accnum, String pin1) throws WalletException;

	boolean getFundTransaction(long accnum, long accnum1, String pin1, String amount) throws WalletException;
	

}
