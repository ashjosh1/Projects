package com.WalletJDBC.service;



import com.WalletJDBC.Dao1.DAOimpl1;
import com.WalletJDBC.Dao1.Dao1;
import com.WalletJDBC.Exception.WalletException;
import com.WalletJDBC.bean.Customer;

public class ServiceImpl implements Service{

	
	Dao1 dao=new DAOimpl1();
	@Override
	public boolean validateCustomer(Customer c) throws WalletException {
		// TODO Auto-generated method stub
		if(validateName(c.getName())&& validateMobile(c.getMobile())&&validateEmail(c.getEmail())&&validateGender(c.getGender())&&validateAge(c.getAge())) {
			return true;
		}
		
		return false;
	}
	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty()|| name==null) {
			throw new WalletException("employee name canot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("name should start with capital letter");
				
			}
		}
		return true;
	}
	private boolean validateMobile(String Mobile) throws WalletException {
		if(Mobile.isEmpty()|| Mobile==null) {
			throw new WalletException("employee mobile canot be empty");
			
		}
		else
		{
			if(!Mobile.matches("\\d{10}")) {
				throw new WalletException("mobile should contain 10 numbers");
			}
		}
		return true;
		
	}
	private boolean validateEmail(String email) throws WalletException{
		if(!email.matches("[A-za-z0-9_]+@[a-z]+\\.com"))
				{
					throw new WalletException("please enter a valid email id");
				}
		return true;
		
	}
	private boolean validateAccountType(String accounttype) throws WalletException{
		if(accounttype.isEmpty()|| accounttype==null) {
			throw new WalletException("accounttype name canot be empty");
		}else if(accounttype.equalsIgnoreCase("savings")||accounttype.equalsIgnoreCase("current")){
			return true;
		}
		throw new WalletException("invalidated");

	}
	private boolean validateGender(String gender) throws WalletException{
		if(gender.isEmpty()|| gender==null) {
			throw new WalletException("gender name canot be empty");
		}
		else if(gender.equalsIgnoreCase("female")||gender.equalsIgnoreCase("male")){
			return true;
				
			}
		throw new WalletException("invalidated");
		}
	private boolean validateAge(String age) throws WalletException{
		if(age.isEmpty()|| age==null) {
			throw new WalletException("age can not be empty");}
        if(Integer.parseInt(age)<18) {
				throw new WalletException("age is not 18");}
			
		return true;
		
		
	
		
	}
	public boolean validatePin(String pin) throws WalletException{
		if(pin.isEmpty()|| pin==null) {
			throw new WalletException("pin name canot be empty");}
			else
			{
				if(!pin.matches("\\d{4}")) {
					throw new WalletException("pin should contain 4 numbers");
				}
			}
			return true;}
		
		
	
		
	
	
	

	@Override
	public long CreateAccount(Customer c) throws WalletException {
		// TODO Auto-generated method stub
		return dao.CreateAccount(c);
	}
	@Override
	public boolean ShowBalance(long accnum, String pin1) throws WalletException {
		// TODO Auto-generated method stub
		dao.ShowBalance(accnum, pin1);
		return true;
	}
	@Override
	public boolean getdeposit(long accnum, String pin1, String amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.Deposit(accnum,pin1,amount);
	}
	@Override
	public boolean getWithDraw(long accnum, String pin1, String amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.getWithDrawal(accnum,pin1,amount);
	}
	@Override
	public boolean getFundTransaction(long accnum, long accnum1,String pin1, String amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.getFundTransaction(accnum,accnum1,pin1,amount);
	}
	@Override
	public boolean PrintTransaction(long accnum, String pin1) throws WalletException {
		// TODO Auto-generated method stub
		return dao.PrintTransaction(accnum,pin1);
	}

}
