package com.WalletJDBC.Exception;


	public class WalletException extends Exception  {
		private static final long serialVersionUID = 726264577455921591L;

		public WalletException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}
	}

