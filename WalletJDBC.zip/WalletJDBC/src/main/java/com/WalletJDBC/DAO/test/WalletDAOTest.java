package com.WalletJDBC.DAO.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.WalletJDBC.Dao1.DAOimpl1;
import com.WalletJDBC.Dao1.Dao1;
import com.WalletJDBC.Exception.WalletException;
import com.WalletJDBC.bean.Customer;
import com.WalletJDBC.bean.Transaction;


public class WalletDAOTest{

Dao1 dao=new DAOimpl1();
//IDAO dao=null;
      @Before
       public void setup() {
              dao=new DAOimpl1();
       }
       
       @After
       public void tearDown() {
              dao = null;
       }
       

       @Test
       public void testCreateAccount() {
              Customer c = new Customer();
              c.setAccountnumber(5L);
              c.setName("Ashu");
              c.setMobile("1234567890");
              c.setEmail("lavanya@mail.com");
              c.setAddress("Pune");
              c.setBalance(200000);
              c.setPin("1235");
              
              
              try {
                     dao.CreateAccount(c);
                     //boolean c1=dao.ShowBalance(5L,"1235");
                    // assertNotNull(c1); 
                    
              } catch (WalletException e) {
                    
                     System.out.println(e.getMessage());
              }
       }

       @Test
       public void testShowBalance() {
              try {
                     boolean c = dao.ShowBalance(1L,"1234");
                     assertNotNull(c);
                    // boolean c1 = dao.ShowBalance(3L,"2746");
                     //assertNotNull(c1);
              } catch (WalletException e) {
                     // TODO Auto-generated catch block
                     System.out.println(e.getMessage());
              }
       }
       
     

	@Test
       public void testDeposit() {
              try {
            	  Customer c=new Customer();
            	  c.setAccountnumber(1L);
            	  c.setName("ash");
            	  c.setBalance(400);
                    boolean c1=dao.Deposit(1L,"1234","400");
                    assertNotNull(c1);
              } catch (WalletException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
              }
       }
       
      

	@Test
       public void testWithdraw() {
              try { Customer c=new Customer();
        	  c.setAccountnumber(1L);
        	  c.setName("ash");
        	  c.setBalance(100);
        	  boolean c1=dao.Deposit(1L,"1234","100");
              assertNotNull(c1);
              } catch (WalletException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
              }
       }
       
       @Test
       public void testFundTransfer() {
              try {
            	  Customer c=new Customer();
            	  c.setAccountnumber(1L);
            	  c.setName("Ash");
            	  c.setBalance(4000);
                     boolean c1=dao.getFundTransaction(1L,2L,"1234","400");
                     assertNotNull(c1);
              } catch (WalletException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
              }
       }
       
       @Test
       public void testPrintTransaction() throws WalletException {
      
              boolean b = dao.PrintTransaction(1L,"1234");
              assertNotNull(b);
       
       }
       
       






}


