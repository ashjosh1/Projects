package com.WalletJDBC.pi;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.WalletJDBC.Exception.WalletException;
import com.WalletJDBC.bean.Customer;
import com.WalletJDBC.service.Service;
import com.WalletJDBC.service.ServiceImpl;




public class MainApp {

	
		Service iservice=new ServiceImpl();
		Scanner scan=new Scanner(System.in);
		public static void main(String[] args) throws WalletException {
			// TODO Auto-generated method stub
			PropertyConfigurator.configure("resources//log4j.properties");
			String i =null ;
			
			MainApp c=new MainApp();
			while(true) {
				System.out.println("========BankingSystem========");
				System.out.println("1.Create an account");
	            System.out.println("2. Show balance");
				System.out.println("3.Deposit");
				System.out.println("4.WithDraw");
				System.out.println("5.FundTransactions");
				System.out.println("6.Print Transactions");
				System.out.println("7.exit");
				
				i=c.scan.nextLine();
				switch(i) {
				case "1" :
					c.createAccount();
					break;
				case "2" :
					c.ShowBalance();
					break;
				case "3" :
					c.Deposit();
					break;
				case "4":
					c.WithDrawal();
					break;
				case "5":
					c.FundTransaction();
					break;
				case  "6":
					c.PrintTransactions();
					break;
					case "7":
						System.exit(0);
						break;
						
					
				}
		// TODO Auto-generated method stub

	}

}
		private void PrintTransactions() {
			// TODO Auto-generated method stub
			System.out.println("enter your account number");
			String account=scan.nextLine();
			System.out.println("enter pin number");
			String pin1=scan.nextLine();
			try {
				long accnum=Long.parseLong(account);
				boolean cust=iservice.PrintTransaction(accnum,pin1);
				//System.out.println(cust);
			}catch(Exception e) {
				System.err.println("an error occured "+e.getMessage());
			}
		
			
		}
		private void FundTransaction() {
			// TODO Auto-generated method stub
			System.out.println("enter account number  ");
			String account=scan.nextLine();
			System.out.println("enter account number you want to transfer");
			String account1=scan.nextLine();
			System.out.println("enter the amount");
			String amount=scan.nextLine();
			System.out.println("enter pin number");
			String pin1=scan.nextLine();
			try {
				long accnum=Long.parseLong(account);
				long accnum1=Long.parseLong(account1);
				boolean cust=iservice.getFundTransaction(accnum,accnum1,pin1,amount);
				//System.out.println(cust);
			
			}catch(Exception e) {
				System.err.println("an error occured "+e.getMessage());
			}
		
			
		}
		private void WithDrawal() {
			// TODO Auto-generated method stub
			System.out.println("enter account number");
			String account=scan.nextLine();
			System.out.println("enter pin number");
			String pin1=scan.nextLine();
			System.out.println("enter the amount");
			String amount=scan.nextLine();
				try {
					long accnum=Long.parseLong(account);
					boolean cust=iservice.getWithDraw(accnum,pin1,amount);
					//System.out.println(cust);
				}catch(Exception e) {
					System.err.println("an error occured "+e.getMessage());
				}
				
			
			
		}
		private void Deposit() {
			// TODO Auto-generated method stub
			System.out.println("enter account number");
			String account=scan.nextLine();
			System.out.println("enter pin number");
			String pin1=scan.nextLine();
			System.out.println("enter the amount");
			String amount=scan.nextLine();
				try {
					long accnum=Long.parseLong(account);
					boolean cust=iservice.getdeposit(accnum,pin1,amount);
					//System.out.println(cust);
				}catch(Exception e) {
					System.err.println("an error occured "+e.getMessage());
				}
				
			
		}
		private void ShowBalance() {
			// TODO Auto-generated method stub
			Customer c=new Customer();
			System.out.println("enter account number");
			String account=scan.nextLine();
			System.out.println("enter pin number");
			String pin1=scan.nextLine();
			
		
			try {
				 
			long accnum=Long.parseLong(account);
			
				boolean cust=iservice.ShowBalance(accnum,pin1);
				//System.out.println(cust);
				
			}catch(Exception e) {
				System.err.println("an error occured "+e.getMessage());
			}
			
		}
			
		
		private void createAccount() {
			// TODO Auto-generated method stub
			Customer c=new Customer();
			System.out.println("enter name of the customer");
			c.setName(scan.nextLine());
			System.out.println("enter mobile number");
			c.setMobile(scan.nextLine());
			System.out.println("enter email");
			c.setEmail(scan.nextLine());
			System.out.println("type of account");
			c.setAccounttype(scan.nextLine());
			System.out.println("enter pin");
			c.setPin(scan.nextLine());
			
             System.out.println("enter gender");
			c.setGender(scan.nextLine());
			System.out.println("enter age");
			c.setAge(scan.nextLine());
			
			System.out.println("enter balance you want to deposit");
			c.setBalance(Double.parseDouble(scan.next()));
			System.out.println("enter address");
			c.setAddress(scan.next());
			
			
		
			
		
		try {
			boolean result=iservice.validateCustomer(c);
			
			System.out.println("validated");
			if(result) {
				long ret=iservice.CreateAccount(c);
				System.out.println("customer with accountnumber "+ret+" added successfully");
			}
		}
		catch(WalletException e) {
			System.err.println("an error occured "+e.getMessage());
			
		
		}
		
		}
		
	}

			
		
