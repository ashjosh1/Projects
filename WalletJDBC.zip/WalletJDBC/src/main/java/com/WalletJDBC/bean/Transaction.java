package com.WalletJDBC.bean;

import java.sql.Date;
import java.time.LocalDateTime;

public class Transaction {
	
		private double amount;
		private String transtype;
		private Date date;
		private long accnum;
		private int Transid;
		public long getAccnum() {
			return accnum;
		}
		public void setAccnum(long accnum) {
			this.accnum = accnum;
		}
		public int getTransid() {
			return Transid;
		}
		public void setTransid(int transid) {
			this.Transid = transid;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		public String getTranstype() {
			return transtype;
		}
		public void setTranstype(String transtype) {
			this.transtype = transtype;
		}
		public Date getDate() {
			return date;
		}
		public void setDate(Date date) {
			this.date = date;
		}
		public Transaction() {}
		public Transaction(long Accnum,double amount, String transtype, Date time) {
			super();
			this.amount = amount;
			this.transtype = transtype;
			this.date = date;
			this.accnum=Accnum;
			
		}
		@Override
		public String toString() {
			return "Transaction [Accnum  "+accnum+ "  , amount "+amount+" ,Transtype "+transtype+", date "+date+ "]";
		}
	
}
