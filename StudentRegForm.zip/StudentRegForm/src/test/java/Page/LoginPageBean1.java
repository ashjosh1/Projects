package Page;

import org.openqa.selenium.WebDriver;

public class LoginPageBean1 {
	WebDriver driver1;
	private LoginPageBean1 loginPageBean1;
	
	
	
	
	
	
	
	
}
