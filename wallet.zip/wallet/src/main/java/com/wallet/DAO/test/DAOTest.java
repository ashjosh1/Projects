package com.wallet.DAO.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.wallet.DAO.DAO;
import com.wallet.DAO.IDAO;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;

public class DAOTest {



		
		IDAO dao=new DAO();
		//IDAO dao=null;
		      @Before
		       public void setup() {
		              dao=new DAO();
		       }
		       
		       @After
		       public void tearDown() {
		              dao = null;
		       }
		       

		       @Test
		       public void testCreateAccount() {
		              Customer c = new Customer();
		              c.setAccountnumber(12345678904L);
		              c.setName("Lavanya");
		              c.setMobile("1234567890");
		              c.setEmail("lavanya@mail.com");
		              c.setAddress("Pune");
		              c.setBalance(200000);
		              c.setPin("3456");
		              
		              
		              try {
		                     dao.CreateAccount(c);
		                     Customer c1=dao.getShowbalance(12345678904L, "3456");
		                     assertNotNull(c1);
		              } catch (WalletException e) {
		                    
		                     System.out.println(e.getMessage());
		              }
		       }

		       @Test
		       public void testShowBalance() {
		              try {
		                     Customer c = dao.getShowbalance(12345678904L,"3456");
		                     assertNotNull(c);
		                     Customer c1 = dao.getShowbalance(12345678903L,"7869");
		                     assertNotNull(c1);
		              } catch (WalletException e) {
		                     // TODO Auto-generated catch block
		                     System.out.println(e.getMessage());
		              }
		       }
		       
		     

			@Test
		       public void testDeposit() {
		              try {
		            	  Customer c=new Customer();
		            	  c.setAccountnumber(12345678904L);
		            	  c.setName("Ben");
		            	  c.setBalance(4000);
		                     assertNotEquals(c,dao.getDeposit(12345678904L,"3456","4000"));
		              } catch (WalletException e) {
		                     // TODO Auto-generated catch block
		                     e.printStackTrace();
		              }
		       }
		       
		      

			@Test
		       public void testWithdraw() {
		              try { Customer c=new Customer();
	            	  c.setAccountnumber(12345678904L);
	            	  c.setName("Ben");
	            	  c.setBalance(4000);
	                     assertNotEquals(c,dao.getWithdraw(12345678904L,"3456","4000"));
		              } catch (WalletException e) {
		                     // TODO Auto-generated catch block
		                     e.printStackTrace();
		              }
		       }
		       
		       @Test
		       public void testFundTransfer() {
		              try {
		            	  Customer c=new Customer();
		            	  c.setAccountnumber(12345678904L);
		            	  c.setName("Ben");
		            	  c.setBalance(4000);
		                     assertNotEquals(c,dao.getFundTransaction(12345678904L,12345678903L,"40"));
		              } catch (WalletException e) {
		                     // TODO Auto-generated catch block
		                     e.printStackTrace();
		              }
		       }
		       
		       @Test
		       public void testPrintTransaction() throws WalletException {
		      
		              Transaction b = dao.PrintTransaction(12345678904L,"3456");
		              assertNull(b);
		       
		       }
		       
		       



		


	}


