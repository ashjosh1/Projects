package com.wallet.DAO;


import java.util.HashMap;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;

public interface IDAO {
	

	long CreateAccount(Customer c) throws WalletException;



	Customer getShowbalance(long accnum, String pin1) throws WalletException;



	Customer getDeposit(long accnum, String pin1, String amount) throws WalletException;



	Customer getWithdraw(long accnum, String pin1, String amount)throws WalletException ;



	Customer getFundTransaction(long accnum, long accnum1, String amount)throws WalletException ;



	Transaction PrintTransaction(Long accnum, String pin1) throws WalletException;





	
	

	
;
}
