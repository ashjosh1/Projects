package com.wallet.DAO;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Scanner;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;

public class DAO implements IDAO {
	static HashMap<Long, Customer> customerMap=WalletDB.getCustomerMap();
	static HashMap<Integer, Transaction> transactionMap=WalletDB.getTransactionMap();
	int transId=0;
	
	@Override
	
	public long CreateAccount(Customer c) throws WalletException {
		// TODO Auto-generated method stub

	try {
		if(customerMap.size()==0) {
			c.setAccountnumber(12345678905L);
		}
		else {
			Optional<Long> id=customerMap.keySet().stream().max(new Comparator<Long>() {
				@Override
				public int compare(Long x,Long y) {
					return x>y?1:x<y?-1:0;
				}
			});
			long reqid=id.get()+1;
			c.setAccountnumber(reqid);
			
		}
		customerMap.put(c.getAccountnumber(), c);
		return c.getAccountnumber();
		
	}catch(Exception ex) {
		throw new WalletException(ex.getMessage());
	}
	



}
	@Override
	public Customer getShowbalance(long accnum,String pin1) throws WalletException {
		// TODO Auto-generated method stub
try {
			
			// TODO Auto-generated method stub
			Customer customer= customerMap.get(accnum);
			
			if(customer==null) {
				throw new WalletException("customer with accountnumber "+accnum+" not available");
			}else if(customer.getPin().equalsIgnoreCase(pin1)) {
				
			
			return customer;
			}
			else {
				throw new Exception("invalid");
			}
			}catch(Exception ex) {
				throw new WalletException(ex.getMessage());
			}
				
			
		
	}
	@Override
	public Customer getDeposit(long accnum,String pin1,String amount) throws WalletException {
		// TODO Auto-generated method stub
		try {
		Customer customer= customerMap.get(accnum);
		
		if(customer==null) {
			throw new WalletException("customer with accountnumber "+accnum+" not available");
		}else if(customer.getPin().equalsIgnoreCase(pin1)) {
		
		double balance=customer.getBalance()+Double.parseDouble(amount);
		customer.setBalance(balance);
		transId++;
		transactionMap.put(transId,new Transaction(accnum,Double.parseDouble(amount),"fund transer",LocalDateTime.now()));
		return customer;
		}else {
			throw new WalletException("invalid");
		
		
		
		}}catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		
	}}
	@Override
	public Customer getWithdraw(long accnum, String pin1, String amount) throws WalletException {
		// TODO Auto-generated method stub
		
			try {
				Customer customer= customerMap.get(accnum);
				
				if(customer==null) {
					throw new WalletException("customer with accountnumber "+accnum+" not available");
				}else if(customer.getPin().equalsIgnoreCase(pin1)) {
				
				double balance=customer.getBalance()-Double.parseDouble(amount);
				customer.setBalance(balance);
				transId++;
				transactionMap.put(transId,new Transaction(accnum,Double.parseDouble(amount),"fund transer",LocalDateTime.now()));
				return customer;
				}else {
					throw new WalletException("invalid");
				
				
				
				}}catch(Exception ex) {
					throw new WalletException(ex.getMessage());
				
			}
			
	}
	
	@Override
	public Customer getFundTransaction(long accnum,long accnum1, String amount) throws WalletException {
		try {
			Customer c=customerMap.get(accnum);
			Customer c1=customerMap.get(accnum1);
			
			if(c==null || c1==null) {
				throw new WalletException("Invalid account");
				
			}else {
				double amount1=c1.getBalance();
				if(amount1<Double.parseDouble(amount)) {
					System.out.println("insuffiecient");
				}else if(amount1<0){
					throw new WalletException("invalid");
					}else {
						if(accnum==accnum1) {
							throw new WalletException("Invalid");
						}else {
					
					double amount2=amount1-Double.parseDouble(amount);
					c1.setBalance(amount2);
					
					double amount3=c.getBalance();
					double amount31=amount3+Double.parseDouble(amount);
					c.setBalance(amount31);
					transId++;
					transactionMap.put(transId,new Transaction(accnum,Double.parseDouble(amount),"fund transfSer",LocalDateTime.now()));
					
					return c1;
				}
					}
			}}catch(Exception ex) {
				throw new WalletException(ex.getMessage());
		}
		return null;

		
	}
	
		

		
	@Override
	public Transaction PrintTransaction(Long accnum, String pin1) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Customer customer= customerMap.get(accnum);
			
			if(customer==null) {
				throw new WalletException("customer with accountnumber "+accnum+" not available");
			}else if(customer.getPin().equalsIgnoreCase(pin1)) {
				for(int key=1;key<=transactionMap.size();key++) {
					Transaction t=transactionMap.get(key);
					if(t.getAccnum()==accnum) {
						System.out.println(t);
					}
				}
			}
		
	
		

		}catch(Exception ex) {
			throw new WalletException(ex.getMessage());}
		return null;}}
	
