package com.wallet.db;

import java.util.HashMap;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;



public class WalletDB {
	public static HashMap<Long,Customer>
	customerMap=new HashMap<Long,Customer>();
	public static HashMap<Integer, Transaction>
	transactionMap=new HashMap<Integer,Transaction>();
	
	static {
		customerMap.put(12345678901L, new Customer(12345678901L,"marki","9999999999","mark@email.com", "Chennai", 500, "savings","19","female","2234"));
		customerMap.put(12345678902L, new Customer(12345678902L,"pam","9999999998","pam@email.com", "Hyderbad",3000, "Current","45","male","5647"));
		customerMap.put(12345678903L, new Customer(12345678903L,"sravan","9997799999","sravaan@email.com","Bangalore", 1000, "Salary","34","male","7869"));
		customerMap.put(12345678904L, new Customer(12345678904L,"mdany","9999998899","mdany@email.com", "Mumbai", 4500, "Savings","24","male","3456"));
		
	
	}
	public static HashMap<Long, Customer> getCustomerMap(){
		return customerMap;
	}
	public static HashMap<Integer, Transaction> getTransactionMap() {
		 //TODO Auto-generated method stub
		return transactionMap;
	}}
	





