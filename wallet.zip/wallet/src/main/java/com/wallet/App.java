package com.wallet;

import java.util.HashMap;
import java.util.Scanner;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;
import com.wallet.service.IService;
import com.wallet.service.ServiceWallet;


public class App {
	 
	static HashMap<Long, Customer> custMap=WalletDB.getCustomerMap();
	IService iservice=new ServiceWallet();
	Scanner scan=new Scanner(System.in);
	public static void main(String[] args) throws WalletException {
		// TODO Auto-generated method stub
		String i =null ;
		
		App c=new App();
		while(true) {
			System.out.println("========BankingSystem========");
			System.out.println("1.Create an account");
            System.out.println("2. Show balance");
			System.out.println("3.Deposit");
			System.out.println("4.WithDraw");
			System.out.println("5.FundTransactions");
			System.out.println("6.Print Transactions");
			System.out.println("");
			i=c.scan.nextLine();
			switch(i) {
			case "1" :
				c.createAccount();
				break;
			case "2" :
				c.Showbalance();
				break;
			case "3" :
				c.getDeposit();
				break;
			case "4":
				c.getWithdraw();
				break;
			case "5":
				c.getFundTransaction();
				break;
			case  "6":
				c.PrintTranscation();
				break;
				case "7":
					System.exit(0);
					break;
					
				
			}
		}
	}
	private void PrintTranscation() {
		// TODO Auto-generated method stub
		System.out.println("enter your account number");
		String account=scan.nextLine();
		System.out.println("enter pin number");
		String pin1=scan.nextLine();
		try {
			long accnum=Long.parseLong(account);
			Transaction cust=iservice.PrintTransaction(accnum,pin1);
			System.out.println(cust);
		}catch(Exception e) {
			System.err.println("an error occured "+e.getMessage());
		}
	
		
	}
	private void getFundTransaction() {
		// TODO Auto-generated method stub
		System.out.println("enter account number you want to transfer ");
		String account=scan.nextLine();
		System.out.println("enter your account number");
		String account1=scan.nextLine();
		System.out.println("enter the amount");
		String amount=scan.nextLine();
		System.out.println("enter pin number");
		String pin1=scan.nextLine();
		try {
			long accnum=Long.parseLong(account);
			long accnum1=Long.parseLong(account1);
			Customer cust=iservice.getFundTransaction(accnum,accnum1,amount);
			System.out.println(cust);
		}catch(Exception e) {
			System.err.println("an error occured "+e.getMessage());
		}
	
		
	}
	private void getWithdraw() {
		// TODO Auto-generated method stub
		System.out.println("enter account number");
		String account=scan.nextLine();
		System.out.println("enter pin number");
		String pin1=scan.nextLine();
		System.out.println("enter the amount");
		String amount=scan.nextLine();
			try {
				long accnum=Long.parseLong(account);
				Customer cust=iservice.getWithdraw(accnum,pin1,amount);
				System.out.println(cust);
			}catch(Exception e) {
				System.err.println("an error occured "+e.getMessage());
			}
		
	}
	private void getDeposit() {
		// TODO Auto-generated method stub
		System.out.println("enter account number");
		String account=scan.nextLine();
		System.out.println("enter pin number");
		String pin1=scan.nextLine();
		System.out.println("enter the amount");
		String amount=scan.nextLine();
			try {
				long accnum=Long.parseLong(account);
				Customer cust=iservice.getdeposit(accnum,pin1,amount);
				System.out.println(cust);
			}catch(Exception e) {
				System.err.println("an error occured "+e.getMessage());
			}
			
		
		
	}
	private void Showbalance() {
		// TODO Auto-generated method stub
		Customer c=new Customer();
		System.out.println("enter account number");
		String account=scan.nextLine();
		System.out.println("enter pin number");
		String pin1=scan.nextLine();
		
	
		try {
			 
		long accnum=Long.parseLong(account);
		
			Customer cust=iservice.getShowBalance(accnum,pin1);
			System.out.println(cust);
			
		}catch(Exception e) {
			System.err.println("an error occured "+e.getMessage());
		}
		
	}
		
		
	
	private void createAccount() {
		// TODO Auto-generated method stub
		Customer c=new Customer();
		System.out.println("enter name of the customer");
		c.setName(scan.nextLine());
		System.out.println("enter mobile number");
		c.setMobile(scan.nextLine());
		System.out.println("enter email");
		c.setEmail(scan.nextLine());
		System.out.println("enter address");
		c.setAddress(scan.nextLine());
		System.out.println("type of account");
		c.setAccounttype(scan.nextLine());
		System.out.println("enter age");
		c.setAge(scan.nextLine());
		System.out.println("enter gender");
		
		c.setGender(scan.nextLine());
		System.out.println("enter balance you want to deposit");
		c.setBalance(Double.parseDouble(scan.next()));
		
	
		
	
	try {
		boolean result=iservice.validateCustomer(c);
		
		System.out.println("validated");
		if(result) {
			long ret=iservice.CreateAccount(c);
			System.out.println("customer with accountnumber "+ret+" added successfully");
		}
	}
	catch(WalletException e) {
		System.err.println("an error occured "+e.getMessage());
		
	
	}
	System.out.println("enter pin");
	c.setPin(scan.nextLine());
	}
	
}

	
