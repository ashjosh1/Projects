package com.wallet.service;

import java.util.Collection;

import com.wallet.DAO.DAO;
import com.wallet.DAO.IDAO;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;

public class ServiceWallet implements  IService {
	IDAO idao=new DAO();
	@Override
	public boolean validateCustomer(Customer c) throws WalletException {
		// TODO Auto-generated method stub
		if(validateName(c.getName())&& validateMobile(c.getMobile())&&validateEmail(c.getEmail())&&validateGender(c.getGender())&&validateAge(c.getAge())) {
			return true;
		}
		
		return false;
	}
	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty()|| name==null) {
			throw new WalletException("employee name canot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("name should start with capital letter");
				
			}
		}
		return true;
	}
	private boolean validateMobile(String Mobile) throws WalletException {
		if(Mobile.isEmpty()|| Mobile==null) {
			throw new WalletException("employee mobile canot be empty");
			
		}
		else
		{
			if(!Mobile.matches("\\d{10}")) {
				throw new WalletException("mobile should contain 10 numbers");
			}
		}
		return true;
		
	}
	private boolean validateEmail(String email) throws WalletException{
		if(!email.matches("[A-za-z0-9_]+@[a-z]+\\.com"))
				{
					throw new WalletException("please enter a valid email id");
				}
		return true;
		
	}
	private boolean validateAccountType(String accounttype) throws WalletException{
		if(accounttype.isEmpty()|| accounttype==null) {
			throw new WalletException("accounttype name canot be empty");
		}else if(accounttype.equalsIgnoreCase("savings")||accounttype.equalsIgnoreCase("current")){
			return true;
		}
		throw new WalletException("invalidated");

	}
	private boolean validateGender(String gender) throws WalletException{
		if(gender.isEmpty()|| gender==null) {
			throw new WalletException("gender name canot be empty");
		}
		else if(gender.equalsIgnoreCase("female")||gender.equalsIgnoreCase("male")){
			return true;
				
			}
		throw new WalletException("invalidated");
		}
	private boolean validateAge(String age) throws WalletException{
		if(age.isEmpty()|| age==null) {
			throw new WalletException("age can not be empty");}
        if(Integer.parseInt(age)<18) {
				throw new WalletException("age is not 18");}
			
		return true;
		
		
	
		
	}
	public boolean validatePin(String pin) throws WalletException{
		if(pin.isEmpty()|| pin==null) {
			throw new WalletException("pin name canot be empty");}
			else
			{
				if(!pin.matches("\\d{4}")) {
					throw new WalletException("pin should contain 4 numbers");
				}
			}
			return true;}
		
		
	
		
	


	@Override
	public long CreateAccount(Customer c) throws WalletException {
		// TODO Auto-generated method stub
		return idao.CreateAccount(c);
	}
	@Override
	public boolean validatePin(Customer c) throws WalletException {
		// TODO Auto-generated method stub
		if(validatePin(c.getPin()));
		return true;
	}
	@Override
	public Customer getShowBalance(long accnum, String pin1) throws WalletException {
		// TODO Auto-generated method stub
		return idao.getShowbalance(accnum,pin1);
	}
	@Override
	public Customer getdeposit(long accnum,String pin1,String amount) throws WalletException {
		// TODO Auto-generated method stub
		return idao.getDeposit(accnum, pin1, amount);
	}
	@Override
	public Customer getWithdraw(long accnum, String pin1, String amount) throws WalletException {
		// TODO Auto-generated method stub
		return idao.getWithdraw(accnum, pin1, amount) ;
	}
	@Override
	public Customer getFundTransaction(long accnum,long accnum1, String amount) throws WalletException {
		// TODO Auto-generated method stub
		return idao.getFundTransaction(accnum,accnum1,amount);
	}
	@Override
	public Transaction PrintTransaction(long accnum, String pin1) throws WalletException {
		// TODO Auto-generated method stub
		return idao.PrintTransaction(accnum, pin1);
	}
	

}
