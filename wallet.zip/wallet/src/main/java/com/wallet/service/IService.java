


	package com.wallet.service;

	import java.util.Collection;

	import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;


	public interface IService {
		long CreateAccount(Customer c) throws WalletException;

		boolean validateCustomer(Customer c) throws WalletException;
		boolean validatePin(Customer c)throws WalletException;

		Customer getShowBalance(long accnum,String pin1)throws WalletException;

		


		Customer getdeposit(long accnum, String pin1, String amount) throws WalletException;

		Customer getWithdraw(long accnum, String pin1, String amount)throws WalletException;

	

		Customer getFundTransaction(long accnum, long accnum1, String amount) throws WalletException;

	

		Transaction PrintTransaction(long accnum, String pin1) throws WalletException;

	}

