package com.wallet.bean;

import java.time.LocalDateTime;

public class Transaction {
	private double amount;
	private String transtype;
	private LocalDateTime time;
	private long Accnum;
	private int Transid;
	public long getAccnum() {
		return Accnum;
	}
	public void setAccnum(long accnum) {
		Accnum = accnum;
	}
	public int getTransid() {
		return Transid;
	}
	public void setTransid(int transid) {
		Transid = transid;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getTranstype() {
		return transtype;
	}
	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public Transaction() {}
	public Transaction(long Accnum,double amount, String transtype, LocalDateTime time) {
		super();
		this.amount = amount;
		this.transtype = transtype;
		this.time = time;
		this.Accnum=Accnum;
		
	}
	@Override
	public String toString() {
		return "Transaction [Accnum  "+Accnum+" transid   "+Transid+ " amount "+amount+" ,Transtype "+transtype+", time "+time+ "]";
	}
	public Object getSenderAccnum() {
		// TODO Auto-generated method stub
		return null;
	}
	
	}



