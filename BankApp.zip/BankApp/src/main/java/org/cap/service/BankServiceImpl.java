package org.cap.service;



import org.cap.Dao.BankDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("bankService")
public class BankServiceImpl implements BankService {

	@Autowired
	BankDao bankDao;

	@Override
	public boolean validateLogin(int customerId, String customerPwd) {
		// TODO Auto-generated method stub
		return bankDao.validateLogin(customerId, customerPwd);
	}

	@Override
	public String getCustomerName(int custId) {
		// TODO Auto-generated method stub
		return bankDao.getCustomerName(custId);
	}
	

}
