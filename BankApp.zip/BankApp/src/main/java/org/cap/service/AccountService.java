package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface AccountService {
	public void createAccount(Account account);
	public List<Account>getAllAccounts(int customerId);
	List<Account> getAccountWithBalance(int custId);
	public void Deposit(Transaction transaction);
	public List<Long> deposit(Integer customerId);
	
}
