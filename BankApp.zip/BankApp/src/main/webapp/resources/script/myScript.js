
window.onload= function(){
       document.getElementById('years').style.display='none';
       }
window.onload=function(){
       document.getElementById('depositBut').style.display='none';
       document.getElementById('withdrawBut').style.display='none';
}
function showBut(){
       if(document.getElementById('deposit').checked){
              document.getElementById('depositBut').style.display='block';
              document.getElementById('withdrawBut').style.display='none';
       }
       else if(document.getElementById('withdraw').checked){
              document.getElementById('withdrawBut').style.display='block';
              document.getElementById('depositBut').style.display='none';
              }
       else{
              document.getElementById('depositBut').style.display='none';
              document.getElementById('withdrawBut').style.display='none';
       }
}
function validateForm(){
       var uname=myform.customerId.value;
       var upwd=myform.customerPwd.value;
       
       var flag=false;
       if(uname==""||uname==null){
              document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
              
       }
       else if(upwd=="" || upwd==null)
              {
              flag=false;
              document.getElementById('userErrMsg').innerHTML="";
              document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
              }
       else{
              flag=true;
              document.getElementById('userErrMsg').innerHTML="";
              document.getElementById('pwdErrMsg').innerHTML="";
       }
       if(!uname.isDigit){
              document.getElementById('userErrMsg').innerHTML=" * customer Id should be a Integer.";       
       }
       return flag;
}

function showYear(){
       if(document.getElementById('rd').checked ||
                     document.getElementById('fd').checked)
              document.getElementById('years').style.display='block';
       else
              document.getElementById('years').style.display='none';
}
function openingBal() {
       var opnBal=accform.openingBalance.value;
       var flag=false;
       if(document.getElementById('rd').checked)
              {
              if (opnBal<=500) {
                     document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open RD is 600.";
              }
              else {
                     flag=true;
                     document.getElementById('errMsg').innerHTML="";
              }
              }
       else if (document.getElementById('fd').checked) {
              if (opnBal<=1000) {
                     document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open FD is 1000.";
              }
              else {
                     flag=true;
                     document.getElementById('errMsg').innerHTML="";
              }
       }
       else if (document.getElementById('savings').checked) {
              if (opnBal<=1000) {
                     document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Savings Acc is 500.";
              }
              else {
                     flag=true;
                     document.getElementById('errMsg').innerHTML="";
              }
       }
       else if (document.getElementById('current').checked) {
              if (opnBal<=10000) {
                     document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Current Acc is 10000.";
              }
              else {
                     flag=true;
                     document.getElementById('errMsg').innerHTML="";
              }
       }
       else{
              flag=true;
              document.getElementById('errMsg').innerHTML="";
       }
       return flag;
}


